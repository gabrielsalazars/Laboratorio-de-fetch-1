# lab-apps-eco-fetch | Interactive Media Design
Boilerplate for the students of my Apps Ecosystems' class

**Content:**
<br> <br> 
📂 /public
<ol>
  <li> index.html</li>
  <li> style.css </li>
  <li> sketch.js </li>
</ol>
